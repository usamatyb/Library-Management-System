-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2019 at 04:13 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Usama Tayyab', 'usama@gmail.com', 'usama', 'Usama123', '2023-12-11 09:56:38'),
(2, 'Admin', 'admin@gmail.com', 'admin', 'Admin123', '2023-12-12 10:15:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblauthors`
--

CREATE TABLE `tblauthors` (
  `id` int(11) NOT NULL,
  `AuthorName` varchar(159) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblauthors`
--

INSERT INTO `tblauthors` (`id`, `AuthorName`, `creationDate`, `UpdationDate`) VALUES
(1, 'Abraham Silberschatz','2023-12-11 13:35:25', '2023-12-12 16:00:42'),
(2, 'Peter B. Galvin','2023-12-11 18:45:25', '2023-12-12 16:02:42'),
(3, 'Charles Crowley','2023-12-11 13:46:55', '0000-00-00 00:00:00'),
(4, 'Dhananjay M. Dhamdhere','2023-12-11 13:47:55', '0000-00-00 00:00:00'),
(5, 'Greg Tomsho','2023-12-11 13:50:55', '0000-00-00 00:00:00'),
(6, 'Ann McHoes','2023-12-11 13:55:55', '0000-00-00 00:00:00'),
(7, 'Ida M. Flynn','2023-12-11 13:56:55', '0000-00-00 00:00:00'),
(8, 'Maurice Bach','2023-12-11 13:58:55', '0000-00-00 00:00:00'),
(9, 'Adam Drozdek','2023-12-11 13:59:55', '0000-00-00 00:00:00'),
(10, 'Thomson H.Cormen','2023-12-11 14:05:55', '0000-00-00 00:00:00'),
(11, 'Robert Sedgewick','2023-12-10 14:07:55', '0000-00-00 00:00:00'),
(12, 'Kevin Wayne','2023-12-11 14:08:55', '0000-00-00 00:00:00'),
(13, 'Steve S. Skiena','2023-12-11 14:15:55', '0000-00-00 00:00:00'),
(14, 'Behrouz A. Forouzan','2023-12-11 14:18:55', '0000-00-00 00:00:00'),
(15, 'Peter Lars Dordal','2023-12-11 14:19:55', '0000-00-00 00:00:00'),
(16, 'Olivier Bonaventure','2023-12-11 14:15:55', '0000-00-00 00:00:00'),
(17, 'Alberto Leon-Garcia','2023-12-11 14:20:55', '0000-00-00 00:00:00'),
(18, 'Indra Widjaja','2023-12-11 14:21:55', '0000-00-00 00:00:00'),
(19, 'Gary Bronson','2023-12-11 14:22:15', '0000-00-00 00:00:00'),
(20, 'Marijn Haverbeke','2023-12-11 14:22:55', '0000-00-00 00:00:00'),
(21, 'Robert C Martin','2023-12-11 14:23:55', '0000-00-00 00:00:00'),
(22, 'Joe Bentley','2023-12-11 14:24:55', '0000-00-00 00:00:00'),
(23, 'Brian W. Kernighan','2023-12-11 14:25:55', '0000-00-00 00:00:00'),
(24, 'Dennis M. Ritchie','2023-12-11 14:30:55', '0000-00-00 00:00:00'),
(25, 'Joshua Bloch','2023-12-11 14:32:55', '0000-00-00 00:00:00'),
(26, 'Albert J. Marcella Jr.','2023-12-11 14:33:55', '0000-00-00 00:00:00'),
(27, 'Doug Menendez', '2023-12-11 14:35:55', '0000-00-00 00:00:00'),
(28, 'Dr. Akashdeep Bhardwaj', '2023-12-11 14:40:55', '0000-00-00 00:00:00'),
(29, 'Keshav Kaushik','2023-12-11 14:45:55', '0000-00-00 00:00:00'),
(30, 'Eoghan Casey','2023-12-11 14:50:55', '0000-00-00 00:00:00'),
(31, 'Dr. Chuck Easttom','2023-12-11 14:55:55', '0000-00-00 00:00:00'),
(32, 'Mark Ciampa','2023-12-11 14:58:55', '0000-00-00 00:00:00'),
(33, 'Jhon Erickson', '2023-12-11 14:59:55', '0000-00-00 00:00:00'),
(34, ' Greg Gagne', '2023-12-11 15:59:55', '0000-00-00 00:00:00')
;
-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `id` int(11) NOT NULL,
  `BookName` varchar(255) DEFAULT NULL,
  `CatId` int(11) DEFAULT NULL,
  `AuthorId` int(11) DEFAULT NULL,
  `ISBNNumber` varchar(15) DEFAULT NULL,
  `Edition` varchar(10) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`id`, `BookName`, `CatId`, `AuthorId`, `ISBNNumber`, `Edition`, `RegDate`, `UpdationDate`) VALUES
(1, 'Operating Systems Concepts',2 , '1', '978-1119553331', '10th', '2023-12-11 10:40:25', '2023-12-12 16:00:42'),
(2, 'Operating System: A Design-oriented Approach', 2, 3, '978-0763737698',  '1st', '2023-12-11 10:41:55', '0000-00-00 00:00:00'),
(3, 'Operating Systems: A Concept-Based Approach', 2, 4, '978-0072957693', 'Int.', '2023-12-11 10:42:55', '0000-00-00 00:00:00'),
(4, 'Guide to Operating Systems', 2, 5, '978-1305107649', '5th', '2023-12-11 10:43:55', '0000-00-00 00:00:00'),
(5, 'Understanding Operating Systems', 2, 6, '978-1285096551', '7th','2023-12-11 10:45:55', '0000-00-00 00:00:00'),
(6, 'Design of the UNIX Operating Systems', 2, 8, '978-0132017992', '1st','2023-12-11 10:46:55', '0000-00-00 00:00:00'),

(7, 'Data Structures and Algorithms in C++', 3, 9, '978-1306391753', '4th','2023-12-11 10:48:55', '0000-00-00 00:00:00'),
(8, 'Introduction to Algorithms', 3, 10, '978-0262033848', '3rd','2023-12-11 10:49:55', '0000-00-00 00:00:00'),
(9, 'Algorithms', 3, 11, '978-0321573513', '4th','2023-12-11 10:50:55', '0000-00-00 00:00:00'),
(10, 'The Algorithm Design Manual', 3, 13, '978-1849967204', '2nd','2023-12-11 10:55:55', '0000-00-00 00:00:00'),

(11, 'Data Communications and Networking', 5, 14, '978-0073376226', '5th','2023-12-11 11:00:55', '0000-00-00 00:00:00'),
(12, 'An Introduction to Computer Networks', 5, 15, '978-0995180719', '2nd','2023-12-11 11:01:55', '0000-00-00 00:00:00'),
(13, 'Computer Networking : Principles, Protocols and Practice', 5, 16, '978-1473729572', '1st','2023-12-11 11:02:55', '0000-00-00 00:00:00'),
(14, 'Communication Networks', 5, 17, '978-0072463521', '2nd','2023-12-11 11:03:55', '0000-00-00 00:00:00'),

(15, 'A First Book of C++', 4, 19, '978-1111531003', '4th','2023-12-11 11:04:55', '0000-00-00 00:00:00'),
(16, 'Eloquent JavaScript: A Modern Introduction to Programming', 4, 20, '978-1593275846', '3rd','2023-12-11 11:11:55', '0000-00-00 00:00:00'),
(17, 'Clean Code: A Handbook of Agile Software and Craftsmanship', 4, 21, '978-0132350884', '1st','2023-12-11 11:12:55', '0000-00-00 00:00:00'),
(18, 'Programming Pearls', 4, 22, '978-0201657883', '2nd','2023-12-11 11:13:55', '0000-00-00 00:00:00'),
(19, 'C Programming Language', 4, 23, '978-0131103627', '2nd','2023-12-11 11:14:55', '0000-00-00 00:00:00'),
(20, 'Effective Java', 4, 25, '978-0134685991', '3rd','2023-12-11 11:15:55', '0000-00-00 00:00:00'),

(21, 'Cyber Forensics From Data to Digital Evidence', 1, 26, '978-0471789879', '1st','2023-12-11 14:16:55', '0000-00-00 00:00:00'),
(22, 'Practical Digital Forensics', 1, 28, '978-9355511454', '1st','2023-12-11 14:17:55', '0000-00-00 00:00:00'),
(23, 'Handbook of Digital Forensics and Investigation', 1, 30, '978-0123742674', '2nd','2023-12-11 14:18:55', '0000-00-00 00:00:00'),

(24, 'Computer Security Fundamentals', 6, 31, '978-0789748904', '3rd','2023-12-11 14:19:55', '0000-00-00 00:00:00'),
(25, 'CompTIA Security+ Guide to Network Security Fundamentals', 6, 32, '978-1337288781', '6th','2023-12-11 14:20:55', '0000-00-00 00:00:00'),
(26, 'Hacking the Art of Exploitation', 6, 33, '978-1593271442', '2nd', '2023-12-11 14:25:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(150) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Status`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Digital Forensics', 1, '2023-12-11 13:00:25', '2023-12-12 16:00:42'),
(2, 'Operating Systems', 1, '2023-12-11 13:05:39', '2023-12-18 17:13:03'),
(3, 'Data Structures and Algorithms', 1, '2023-12-11 13:10:55', '0000-00-00 00:00:00'),
(4, 'Computer Programming', 1, '2023-12-11 13:16:16', '0000-00-00 00:00:00'),
(5, 'Data Communication and Networks', 1, '2023-12-11 13:20:16', '0000-00-00 00:00:00'),
(6, 'Cyber Security', 1, '2023-12-11 13:25:16', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblissuedbookdetails`
--

CREATE TABLE `tblissuedbookdetails` (
  `id` int(11) NOT NULL,
  `BookId` int(11) DEFAULT NULL,
  `StudentID` varchar(150) DEFAULT NULL,
  `IssuesDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ReturnDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RetrunStatus` int(1) DEFAULT NULL,
  `fine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissuedbookdetails`
--

INSERT INTO `tblissuedbookdetails` (`id`, `BookId`, `StudentID`, `IssuesDate`, `ReturnDate`, `RetrunStatus`, `fine`) VALUES
(1, 22, 'F21BINCE1M03093', '2023-12-18 11:09:47', '2023-12-22 11:15:20', 1, 0),
(2, 1, 'F21BINCE1M03030', '2023-12-18 11:12:27', '2023-12-22 11:15:23', 1, 0),
(3, 3, 'F21BINCE1M03030', '2023-12-26 10:13:40', NULL, 0, NULL),
(4, 7, 'F21BINCE1M03001', '2023-12-26 10:23:23', NULL, 0, NULL),
(5, 12, 'F21BINCE1M03093', '2023-12-26 10:59:26', NULL, 0, NULL),
(6, 13, 'F21BINCE1M03000', '2023-12-26 13:02:55', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `StudentId` varchar(100) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `MobileNumber` varchar(20) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `StudentId`, `FullName`, `EmailId`, `MobileNumber`, `Password`, `Status`, `RegDate`, `UpdationDate`) VALUES
(1, 'F21BINCE1M03093', 'Hasnain Bhatti', 'hasnain@gmail.com', '03001234561', 'Hasnain123', 1, '2023-12-11 15:37:05', '2023-12-21 14:11:39'),
(2, 'F21BINCE1M03030', 'Muntaha Nasir', 'muntaha@gmail.com', '03001234562', 'Muntaha123', 1, '2023-12-11 15:41:27', '2023-12-21 14:12:04'),
(3, 'F21BINCE1M03008', 'Muhammad Adeel', 'adeel@gmail.com', '03001234563', 'Adeel123', 0, '2023-12-15 13:40:30', '2023-12-16 14:12:27'),
(4, 'F21BINCE1M03001', 'Zain Ul Husayn', 'zain@gmail.com', '03001234564', 'Zain123', 1, '2023-12-15 14:00:59', '2023-12-20 14:12:50'),
(5, 'F21BINCE1M03000', 'Ali Haider', 'ali@gmail.com', '03001234565', 'Ali123', 1, '2023-12-22 13:46:30', NULL),
(6, 'F21BINCE1M00000', 'Hassan Askari', 'hassan@gmail.com', '03001234566', 'Hassan123', 1, '2023-12-22 12:46:30', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- Indexes for table `tblauthors`
--
ALTER TABLE `tblauthors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ISBNNumber` (`ISBNNumber`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `StudentId` (`StudentId`),
  ADD UNIQUE KEY `EmailId` (`EmailId`),
  ADD UNIQUE KEY `MobileNumber` (`MobileNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblauthors`
--
ALTER TABLE `tblauthors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
