<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Library Management System | </title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
<style>
        body {
            background-image: url('assets/img/4.jpg');
            background-size: cover;
            background-position: center, fixed;
            /* Additional styles if needed */
        }
</style>

    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>

    <div class="box" style="center;
    height: 450px;
    width: 600px;
    background-color: black;
    margin: 70px auto;
    opacity: 0.6;
    color: white;">
    <br>
    <h1 style="color:white; text-align: center; font-size: 45px; font-family: Cambria; font-weight: bold;">Welcome to Library</h1><br>
    <h1 style="color:white; text-align: center; font-size: 40px;">"Read a lot. Expect something big, something exalting or deepening from a book. No book is worth reading that isn't worth re-reading." – Susan Sontag</h1>
</div>


      </body>
</html>