<?php 
require_once("includes/config.php");

// Code for student ID availability check
if (!empty($_POST["studentid"])) {
    $studentid = $_POST["studentid"];
    
    // Validate if the entered student ID already exists in the database
    $sql = "SELECT StudentId FROM tblstudents WHERE StudentId = :studentid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':studentid', $studentid, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);
    
    if ($query->rowCount() > 0) {
        echo "<span style='color:red'>Student ID already exists.</span>";
        echo "<script>$('#submit').prop('disabled', true);</script>";
    } else {
        echo "<span style='color:green'>Student ID valid for Registration.</span>";
        echo "<script>$('#submit').prop('disabled', false);</script>";
    }
}


?>
